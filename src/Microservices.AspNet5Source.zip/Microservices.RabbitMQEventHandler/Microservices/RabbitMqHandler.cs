﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microservices.Core;
using Microsoft.Extensions.DependencyInjection;

namespace Microservices.RabbitMQEventHandler
{
	public class RabbitMqHandlerMicroservice
	{
		public void Initialize(IMessageHandlersHost host)
		{
			
		}
	}
}
