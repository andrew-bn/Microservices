﻿namespace Microservices.Core
{
	public enum MicroservicesError
	{
		MicroserviceNotFound
	}
}