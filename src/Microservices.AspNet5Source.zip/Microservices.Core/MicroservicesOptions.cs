﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Microservices.Core
{
    public class MicroservicesOptions
    {
		public string DefaultMicroservice { get; set; }
	}
}
